import {Component} from 'angular2/core';

@Component({
    selector: 'my-component',
    template: '
        This is my component!
    '
})
export class MyComponentComponent {
    
}